-- 1. Регистрируем денежную руду
minetest.register_node("geniemod:money_ore", {
    description = "Money Ore",
    tiles = {"money_ore.png"},
    groups = {cracky = 2, stone = 1},
    drop = {
        max_items = 1,
        items = {
            {items = {"geniemod:coin 10"}, rarity = 2},  -- Выпадает 10 монет с шансом
            {items = {"geniemod:coin 5"}},              -- Выпадает 5 монет
        },
    },
})

-- Генерация денежной руды возле железа
minetest.register_ore({
    ore_type = "scatter",
    ore = "geniemod:money_ore",
    wherein = "default:stone",
    clust_scarcity = 8 * 8 * 8,
    clust_num_ores = 2,
    clust_size = 2,
    neighbor = "default:stone_with_iron",
    y_min = -64,
    y_max = -16,
})

-- 2. Регистрируем монеты
minetest.register_craftitem("geniemod:coin", {
    description = "Coin",
    inventory_image = "coin.png",
})

-- 3. Регистрируем горсть монет
minetest.register_craftitem("geniemod:coin_pile", {
    description = "Pile of Coins",
    inventory_image = "coin_pile.png",
})

-- Крафт горсти монет из 9 монет
minetest.register_craft({
    output = "geniemod:coin_pile",
    recipe = {
        {"geniemod:coin", "geniemod:coin", "geniemod:coin"},
        {"geniemod:coin", "geniemod:coin", "geniemod:coin"},
        {"geniemod:coin", "geniemod:coin", "geniemod:coin"},
    }
})

-- 4. Регистрируем "Стол Джина"
minetest.register_node("geniemod:genie_table", {
    description = "Genie Table",
    tiles = {"genie_table_top.png", "genie_table_side.png"},
    groups = {cracky = 3},
    on_construct = function(pos)
        local meta = minetest.get_meta(pos)
        meta:set_string("infotext", "Genie Table: Throw a pile of coins to get a random item!")
        meta:set_int("uses_left", 5)  -- Добавляем счётчик использований
    end,
})

-- Крафт "Стола Джина"
minetest.register_craft({
    output = "geniemod:genie_table",
    recipe = {
        {"", "geniemod:coin_pile", ""},
        {"default:steel_ingot", "", "default:steel_ingot"},
        {"", "", ""},
    }
})

-- 5. Логика для работы "Стола Джина"
minetest.register_abm({
    nodenames = {"geniemod:genie_table"},
    neighbors = {"air"},
    interval = 1.0,  -- Интервал проверки (1 секунда)
    chance = 1,      -- Шанс выполнения (100%)
    action = function(pos, node, active_object_count, active_object_count_wider)
        local objects = minetest.get_objects_inside_radius(pos, 1)
        local meta = minetest.get_meta(pos)
        local uses_left = meta:get_int("uses_left")
        
        for _, obj in ipairs(objects) do
            local entity = obj:get_luaentity()
            -- Проверяем, является ли объект предметом
            if entity and entity.name == "__builtin:item" then
                local stack = ItemStack(entity.itemstring)
                -- Проверяем, является ли предмет "горстью монет"
                if stack:get_name() == "geniemod:coin_pile" then
                    obj:remove()  -- Удаляем монеты
                    minetest.chat_send_all("The Genie Table has taken your coins!")
                    
                    -- Список случайных предметов
                    local items = {
                        "default:gold_ingot",      -- Слиток золота
                        "default:steel_ingot",     -- Слиток железа
                        "default:pick_wood",       -- Деревянная кирка
                        "default:pick_stone",      -- Каменная кирка
                        "default:pick_steel",      -- Железная кирка
                        "default:pick_diamond",    -- Алмазная кирка
                        "default:sword_wood",      -- Деревянный меч
                        "default:sword_stone",     -- Каменный меч
                        "default:sword_steel",     -- Железный меч
                        "default:sword_diamond",   -- Алмазный меч
                        "default:snow 10",         -- Стак снега
                        "default:stone 10",        -- Стак камня
                        "default:wood 10",         -- Стак дерева
                        "geniemod:coin 5",         -- 5 монет
                        "geniemod:coin 10"         -- 10 монет
                    }
                    
                    -- Выбираем случайный предмет из списка
                    local random_item = items[math.random(#items)]
                    
                    -- Выбрасываем случайный предмет
                    minetest.add_item(pos, random_item)

                    -- Уменьшаем количество использований
                    uses_left = uses_left - 1
                    meta:set_int("uses_left", uses_left)
                    
                    if uses_left <= 0 then
                        minetest.chat_send_all("The Genie Table has broken!")
                        minetest.remove_node(pos)  -- Удаляем блок "Стол Джина"
                        return
                    end
                end
            end
        end
    end,
})
